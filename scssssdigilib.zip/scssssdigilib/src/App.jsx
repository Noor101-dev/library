import React, { useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { AppAuthProvider } from "@/lib/AppAuthContext";
import { ToastProvider } from "@/components/ui/Toast";
import { seedDemoData } from "@/lib/seed";

import StudentLogin from "@/pages/StudentLogin";
import LibrarianLogin from "@/pages/LibrarianLogin";
import PageNotFound from "@/pages/PageNotFound";

import LibrarianRoute from "@/components/LibrarianRoute";
import StudentRoute from "@/components/StudentRoute";
import AdminLayout from "@/components/AdminLayout";
import PortalLayout from "@/components/PortalLayout";

import AdminDashboard from "@/pages/admin/AdminDashboard";
import AdminStudents from "@/pages/admin/AdminStudents";
import AdminBooks from "@/pages/admin/AdminBooks";
import AdminIssue from "@/pages/admin/AdminIssue";
import AdminReturns from "@/pages/admin/AdminReturns";
import AdminEvents from "@/pages/admin/AdminEvents";

import StudentHome from "@/pages/portal/StudentHome";
import StudentReader from "@/pages/portal/StudentReader";
import StudentBadges from "@/pages/portal/StudentBadges";
import StudentLeaderboard from "@/pages/portal/StudentLeaderboard";
import StudentWishlist from "@/pages/portal/StudentWishlist";
import StudentAvatarShop from "@/pages/portal/StudentAvatarShop";

export default function App() {
  useEffect(() => {
    seedDemoData();
  }, []);

  return (
    <ToastProvider>
      <AppAuthProvider>
        <Routes>
          <Route path="/" element={<Navigate to="/student-login" replace />} />
          <Route path="/student-login" element={<StudentLogin />} />
          <Route path="/librarian-login" element={<LibrarianLogin />} />

          <Route
            path="/admin"
            element={
              <LibrarianRoute>
                <AdminLayout>
                  <AdminDashboard />
                </AdminLayout>
              </LibrarianRoute>
            }
          />
          <Route
            path="/admin/students"
            element={
              <LibrarianRoute>
                <AdminLayout>
                  <AdminStudents />
                </AdminLayout>
              </LibrarianRoute>
            }
          />
          <Route
            path="/admin/books"
            element={
              <LibrarianRoute>
                <AdminLayout>
                  <AdminBooks />
                </AdminLayout>
              </LibrarianRoute>
            }
          />
          <Route
            path="/admin/issue"
            element={
              <LibrarianRoute>
                <AdminLayout>
                  <AdminIssue />
                </AdminLayout>
              </LibrarianRoute>
            }
          />
          <Route
            path="/admin/returns"
            element={
              <LibrarianRoute>
                <AdminLayout>
                  <AdminReturns />
                </AdminLayout>
              </LibrarianRoute>
            }
          />
          <Route
            path="/admin/events"
            element={
              <LibrarianRoute>
                <AdminLayout>
                  <AdminEvents />
                </AdminLayout>
              </LibrarianRoute>
            }
          />

          <Route
            path="/portal"
            element={
              <StudentRoute>
                <PortalLayout>
                  <StudentHome />
                </PortalLayout>
              </StudentRoute>
            }
          />
          <Route
            path="/portal/read/:bookId"
            element={
              <StudentRoute>
                <StudentReader />
              </StudentRoute>
            }
          />
          <Route
            path="/portal/badges"
            element={
              <StudentRoute>
                <PortalLayout>
                  <StudentBadges />
                </PortalLayout>
              </StudentRoute>
            }
          />
          <Route
            path="/portal/leaderboard"
            element={
              <StudentRoute>
                <PortalLayout>
                  <StudentLeaderboard />
                </PortalLayout>
              </StudentRoute>
            }
          />
          <Route
            path="/portal/wishlist"
            element={
              <StudentRoute>
                <PortalLayout>
                  <StudentWishlist />
                </PortalLayout>
              </StudentRoute>
            }
          />
          <Route
            path="/portal/shop"
            element={
              <StudentRoute>
                <PortalLayout>
                  <StudentAvatarShop />
                </PortalLayout>
              </StudentRoute>
            }
          />

          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </AppAuthProvider>
    </ToastProvider>
  );
}
