import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Student, Book, Loan } from "@/lib/db";
import { useAppAuth } from "@/lib/AppAuthContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/Toast";
import { getLoanStatus, STATUS_STYLES, getCountdown } from "@/lib/dates";

export default function StudentHome() {
  const { student: authStudent, setStudent: setAuthStudent } = useAppAuth();
  const toast = useToast();
  const [student, setStudentData] = useState(null);
  const [loans, setLoans] = useState([]);
  const [digitalBooks, setDigitalBooks] = useState([]);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const s = await Student.get(authStudent.id);
    setStudentData(s);
    const allLoans = await Loan.filter({ student_id: authStudent.id });
    setLoans(allLoans.filter((l) => l.status !== "returned"));
    const books = await Book.filter({ is_digital: true });
    setDigitalBooks(books);
  }

  async function handleCheckin() {
    if (!student) return;
    const today = new Date().toDateString();
    if (student.last_checkin && new Date(student.last_checkin).toDateString() === today) {
      toast("Already checked in today!", "info");
      return;
    }
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const wasYesterday = student.last_checkin && new Date(student.last_checkin).toDateString() === yesterday.toDateString();
    const newStreak = wasYesterday ? (student.current_streak || 0) + 1 : 1;

    const updated = await Student.update(student.id, {
      points: (student.points || 0) + 5,
      current_streak: newStreak,
      last_checkin: new Date().toISOString(),
    });
    setStudentData(updated);
    toast(`+5 points! Streak: ${newStreak} day${newStreak > 1 ? "s" : ""} 🔥`, "success");
  }

  if (!student) return null;

  const checkedInToday = student.last_checkin && new Date(student.last_checkin).toDateString() === new Date().toDateString();
  const overdueBlockActive = loans.some((l) => getLoanStatus(l) === "overdue");

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-purple-500 to-sky-400 text-white border-0">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="font-heading text-xl font-semibold">Hi, {student.full_name.split(" ")[0]}! 👋</div>
            <div className="text-sm opacity-90 mt-1">
              ⭐ {student.points} points · 🔥 {student.current_streak || 0} day streak
            </div>
          </div>
          <Button
            onClick={handleCheckin}
            disabled={checkedInToday}
            className="!bg-white !text-brand-deepPurple hover:!bg-purple-50"
          >
            {checkedInToday ? "Checked in ✓" : "Daily Check-in (+5)"}
          </Button>
        </div>
      </Card>

      <div>
        <h2 className="font-heading font-semibold text-gray-700 mb-3">My Borrowed Books ({loans.length}/4)</h2>
        {loans.length === 0 ? (
          <Card className="text-center text-sm text-gray-400 py-8">No books borrowed right now.</Card>
        ) : (
          <div className="grid sm:grid-cols-2 gap-3">
            {loans.map((l) => {
              const status = getLoanStatus(l);
              return (
                <Card key={l.id} className="flex gap-3 items-center">
                  <div className="w-12 h-16 bg-purple-50 rounded-lg overflow-hidden shrink-0 flex items-center justify-center">
                    {l.book_cover ? <img src={l.book_cover} className="w-full h-full object-cover" /> : "📖"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-gray-800 text-sm truncate">{l.book_title}</div>
                    <span className={`text-xs px-2 py-0.5 rounded-full border mt-1 inline-block ${STATUS_STYLES[status]}`}>
                      {getCountdown(l.due_date)}
                    </span>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <div>
        <h2 className="font-heading font-semibold text-gray-700 mb-3">Digital Storybooks</h2>
        {overdueBlockActive ? (
          <Card className="text-center text-sm text-amber-600 bg-amber-50 border-amber-100 py-6">
            Return your overdue book to unlock digital storybooks.
          </Card>
        ) : digitalBooks.length === 0 ? (
          <Card className="text-center text-sm text-gray-400 py-8">No digital storybooks yet.</Card>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {digitalBooks.map((b) => (
              <Link key={b.id} to={`/portal/read/${b.id}`}>
                <Card className="!p-0 overflow-hidden hover:shadow-md transition-shadow">
                  <div className="h-28 bg-purple-50 flex items-center justify-center">
                    {b.cover_url ? <img src={b.cover_url} className="w-full h-full object-cover" /> : <span className="text-3xl">📚</span>}
                  </div>
                  <div className="p-2">
                    <div className="text-sm font-medium text-gray-800 truncate">{b.title}</div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      <div className="flex gap-3">
        <Link to="/portal/badges" className="btn-secondary text-sm">🏅 My Badges</Link>
        <Link to="/portal/leaderboard" className="btn-secondary text-sm">🏆 Leaderboard</Link>
      </div>
    </div>
  );
}
