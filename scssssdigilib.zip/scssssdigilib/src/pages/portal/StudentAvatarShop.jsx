import React, { useEffect, useState } from "react";
import { AvatarItem, Student } from "@/lib/db";
import { useAppAuth } from "@/lib/AppAuthContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/Toast";

export default function StudentAvatarShop() {
  const { student: authStudent } = useAppAuth();
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [student, setStudentData] = useState(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setItems(await AvatarItem.list());
    setStudentData(await Student.get(authStudent.id));
  }

  async function buy(item) {
    if (!student) return;
    if (student.owned_avatars?.includes(item.id)) {
      toast("You already own this!", "info");
      return;
    }
    if ((student.points || 0) < item.price) {
      toast("Not enough points yet.", "error");
      return;
    }
    const updated = await Student.update(student.id, {
      points: student.points - item.price,
      owned_avatars: [...(student.owned_avatars || []), item.id],
    });
    setStudentData(updated);
    toast(`You got the ${item.name}! ✨`, "success");
  }

  if (!student) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-semibold text-gray-800">Avatar Shop</h1>
        <span className="text-sm font-semibold bg-brand-yellow/30 text-amber-700 px-3 py-1 rounded-full">
          ⭐ {student.points} pts
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {items.map((item) => {
          const owned = student.owned_avatars?.includes(item.id);
          return (
            <Card key={item.id} className="text-center">
              <div className="text-4xl">{item.emoji}</div>
              <div className="font-medium text-sm mt-2 text-gray-800">{item.name}</div>
              <div className="text-xs text-gray-400 capitalize">{item.type}</div>
              <Button
                onClick={() => buy(item)}
                disabled={owned}
                className="w-full mt-3 !text-sm !py-1.5"
                variant={owned ? "secondary" : "primary"}
              >
                {owned ? "Owned ✓" : `${item.price} pts`}
              </Button>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
