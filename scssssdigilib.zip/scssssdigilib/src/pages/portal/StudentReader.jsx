import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Book, Review, Student, Quiz } from "@/lib/db";
import { useAppAuth } from "@/lib/AppAuthContext";
import { useToast } from "@/components/ui/Toast";
import PdfReader from "@/components/PdfReader";
import ImageReader from "@/components/ImageReader";
import { EndOfBookQuiz } from "@/components/EndOfBookQuiz";

const EMOJIS = ["😍", "😊", "😐"];

export default function StudentReader() {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const { student } = useAppAuth();
  const toast = useToast();
  const [book, setBook] = useState(null);
  const [rated, setRated] = useState(false);
  const [showQuiz, setShowQuiz] = useState(false);

  useEffect(() => {
    Book.get(bookId).then(setBook);
    Review.filter({ student_id: student.id, book_id: bookId }).then((r) => setRated(r.length > 0));
  }, [bookId]);

  async function handleRate(emoji) {
    if (rated) return;
    await Review.create({ student_id: student.id, book_id: bookId, rating: emoji, is_digital: true });
    const s = await Student.get(student.id);
    await Student.update(student.id, { points: (s.points || 0) + 2 });
    setRated(true);
    toast("Thanks for rating! +2 points", "success");
  }

  async function fetchQuizForBook(id) {
    const results = await Quiz.filter({ book_id: id });
    return results[0] || null;
  }

  async function handleAwardPoints(pts) {
    if (pts <= 0) return;
    const s = await Student.get(student.id);
    await Student.update(student.id, { points: (s.points || 0) + pts });
  }

  if (!book) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-100 p-3 flex items-center justify-between sticky top-0 z-30">
        <button onClick={() => navigate("/portal")} className="text-gray-500 text-sm">
          ← Back
        </button>
        <div className="font-medium text-sm text-gray-700 truncate max-w-[50%]">{book.title}</div>
        <div className="flex gap-1">
          {EMOJIS.map((e) => (
            <button
              key={e}
              onClick={() => handleRate(e)}
              disabled={rated}
              className="text-xl disabled:opacity-40"
            >
              {e}
            </button>
          ))}
        </div>
      </header>

      {book.digital_pages?.length > 0 ? (
        <ImageReader book={book} onReachedLastPage={() => setShowQuiz(true)} />
      ) : (
        <PdfReader book={book} onReachedLastPage={() => setShowQuiz(true)} />
      )}

      <div className="p-4 text-center">
        <button onClick={() => setShowQuiz(true)} className="text-xs text-brand-purple font-medium">
          Take the quiz →
        </button>
      </div>

      {showQuiz && (
        <EndOfBookQuiz
          bookId={book.id}
          studentId={student.id}
          fetchQuizForBook={fetchQuizForBook}
          onAwardPoints={handleAwardPoints}
          onClose={() => setShowQuiz(false)}
        />
      )}
    </div>
  );
}
