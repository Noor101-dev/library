import React, { useEffect, useState } from "react";
import { WishlistItem } from "@/lib/db";
import { useAppAuth } from "@/lib/AppAuthContext";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/Toast";

export default function StudentWishlist() {
  const { student } = useAppAuth();
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const list = await WishlistItem.list();
    setItems(list.sort((a, b) => (b.voter_ids?.length || 0) - (a.voter_ids?.length || 0)));
  }

  async function suggest(e) {
    e.preventDefault();
    if (!title) return;
    await WishlistItem.create({ title, author, voter_ids: [student.id] });
    setTitle("");
    setAuthor("");
    toast("Suggestion added!", "success");
    load();
  }

  async function toggleVote(item) {
    const voted = item.voter_ids?.includes(student.id);
    const voter_ids = voted
      ? item.voter_ids.filter((id) => id !== student.id)
      : [...(item.voter_ids || []), student.id];
    await WishlistItem.update(item.id, { voter_ids });
    load();
  }

  return (
    <div className="space-y-6">
      <h1 className="font-heading text-2xl font-semibold text-gray-800">Book Wishlist</h1>

      <Card>
        <form onSubmit={suggest} className="flex flex-col sm:flex-row gap-2">
          <input className="input" placeholder="Book title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className="input" placeholder="Author (optional)" value={author} onChange={(e) => setAuthor(e.target.value)} />
          <Button type="submit" className="shrink-0">Suggest</Button>
        </form>
      </Card>

      <div className="space-y-2">
        {items.length === 0 && <p className="text-sm text-gray-400 text-center py-8">No suggestions yet — add one!</p>}
        {items.map((item) => {
          const voted = item.voter_ids?.includes(student.id);
          return (
            <Card key={item.id} className="flex items-center gap-3">
              <div className="flex-1">
                <div className="font-medium text-gray-800 text-sm">{item.title}</div>
                {item.author && <div className="text-xs text-gray-400">{item.author}</div>}
              </div>
              <button
                onClick={() => toggleVote(item)}
                className={`text-sm font-medium px-3 py-1.5 rounded-full border-2 ${
                  voted ? "bg-brand-purple text-white border-brand-purple" : "border-gray-200 text-gray-500"
                }`}
              >
                👍 {item.voter_ids?.length || 0}
              </button>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
