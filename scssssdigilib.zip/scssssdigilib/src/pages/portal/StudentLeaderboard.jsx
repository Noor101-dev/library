import React, { useEffect, useState } from "react";
import { Student, MonthlyEvent } from "@/lib/db";
import { Card } from "@/components/ui/Card";

export default function StudentLeaderboard() {
  const [students, setStudents] = useState([]);
  const [events, setEvents] = useState([]);

  useEffect(() => {
    Student.list("-points").then(setStudents);
    MonthlyEvent.list("-month").then(setEvents);
  }, []);

  const podium = students.slice(0, 3);
  const rest = students.slice(3, 20);

  return (
    <div className="space-y-8">
      <h1 className="font-heading text-2xl font-semibold text-gray-800">Leaderboard</h1>

      {podium.length > 0 && (
        <div className="flex items-end justify-center gap-3">
          {podium[1] && <PodiumSpot s={podium[1]} place={2} height="h-20" />}
          {podium[0] && <PodiumSpot s={podium[0]} place={1} height="h-28" />}
          {podium[2] && <PodiumSpot s={podium[2]} place={3} height="h-14" />}
        </div>
      )}

      <Card className="!p-0 overflow-hidden">
        <div className="divide-y divide-gray-100">
          {rest.map((s, i) => (
            <div key={s.id} className="p-3 flex items-center gap-3">
              <span className="text-sm text-gray-400 w-6">{i + 4}</span>
              <span className="flex-1 text-sm font-medium text-gray-700">{s.full_name}</span>
              <span className="text-sm font-semibold text-brand-purple">⭐ {s.points}</span>
            </div>
          ))}
        </div>
      </Card>

      <div>
        <h2 className="font-heading font-semibold text-gray-700 mb-3">Wall of Fame</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {events.map((e) => (
            <Card key={e.id} className="text-center">
              <div className="w-14 h-14 rounded-full bg-yellow-50 overflow-hidden mx-auto mb-2">
                {e.champion_photo ? (
                  <img src={e.champion_photo} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xl">🏆</div>
                )}
              </div>
              <div className="text-sm font-medium text-gray-800">{e.champion_name}</div>
              <div className="text-xs text-gray-400">{e.month}</div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

function PodiumSpot({ s, place, height }) {
  const medal = place === 1 ? "🥇" : place === 2 ? "🥈" : "🥉";
  return (
    <div className="text-center w-24">
      <div className="text-2xl">{medal}</div>
      <div className="text-xs font-medium text-gray-700 truncate">{s.full_name}</div>
      <div className={`mt-1 bg-purple-100 rounded-t-xl flex items-end justify-center pb-2 ${height}`}>
        <span className="text-xs font-semibold text-brand-deepPurple">{s.points}</span>
      </div>
    </div>
  );
}
