import React, { useEffect, useState } from "react";
import { Badge, Student } from "@/lib/db";
import { useAppAuth } from "@/lib/AppAuthContext";
import { Card } from "@/components/ui/Card";

export default function StudentBadges() {
  const { student: authStudent } = useAppAuth();
  const [badges, setBadges] = useState([]);
  const [earned, setEarned] = useState([]);

  useEffect(() => {
    Badge.list().then(setBadges);
    Student.get(authStudent.id).then((s) => setEarned(s.earned_badges || []));
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="font-heading text-2xl font-semibold text-gray-800">My Badges</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {badges.map((b) => {
          const isEarned = earned.includes(b.id);
          return (
            <Card key={b.id} className={`text-center ${!isEarned && "grayscale opacity-50"}`}>
              <div className="text-4xl">{b.icon}</div>
              <div className="font-heading font-semibold text-sm mt-2 text-gray-800">{b.name}</div>
              <div className="text-xs text-gray-400 mt-1">{b.description}</div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
