import React from "react";
import { Link } from "react-router-dom";

export default function PageNotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center text-center px-4">
      <div>
        <div className="text-6xl mb-4">🔍</div>
        <h1 className="font-heading text-2xl font-semibold text-gray-800">Page not found</h1>
        <Link to="/" className="text-brand-purple font-medium mt-3 inline-block">
          ← Back to login
        </Link>
      </div>
    </div>
  );
}
