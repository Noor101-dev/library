import React, { useEffect, useState } from "react";
import { Book, UploadFile } from "@/lib/db";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/Toast";
import { fetchBookByISBN } from "@/lib/books";

const emptyForm = {
  title: "",
  author: "",
  isbn: "",
  cover_url: "",
  description: "",
  category: "",
  total_copies: 1,
  is_digital: false,
  digital_pdf_url: "",
};

export default function AdminBooks() {
  const toast = useToast();
  const [books, setBooks] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [showForm, setShowForm] = useState(false);
  const [lookingUp, setLookingUp] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setBooks(await Book.list("-created_date"));
  }

  async function lookupISBN() {
    if (!form.isbn) return;
    setLookingUp(true);
    try {
      const result = await fetchBookByISBN(form.isbn.trim());
      if (result) {
        setForm((f) => ({ ...f, ...result }));
        toast("Book details filled in.", "success");
      } else {
        toast("No match found — fill in details manually.", "error");
      }
    } catch {
      toast("Lookup failed — check your connection.", "error");
    } finally {
      setLookingUp(false);
    }
  }

  async function handleCover(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await UploadFile({ file });
    setForm((f) => ({ ...f, cover_url: file_url }));
  }

  async function handlePdf(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await UploadFile({ file });
    setForm((f) => ({ ...f, digital_pdf_url: file_url, is_digital: true }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.title || !form.author) {
      toast("Title and author are required.", "error");
      return;
    }
    await Book.create({
      ...form,
      total_copies: Number(form.total_copies) || 1,
      available_copies: Number(form.total_copies) || 1,
      digital_pages: [],
      borrow_count: 0,
    });
    toast("Book added.", "success");
    setForm(emptyForm);
    setShowForm(false);
    load();
  }

  async function handleDelete(id) {
    if (!window.confirm("Delete this book?")) return;
    await Book.remove(id);
    load();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="font-heading text-2xl font-semibold text-gray-800">Books</h1>
        <Button onClick={() => setShowForm((s) => !s)}>{showForm ? "Cancel" : "+ Add Book"}</Button>
      </div>

      {showForm && (
        <Card>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex gap-2">
              <input
                className="input"
                placeholder="Scan or type ISBN"
                value={form.isbn}
                onChange={(e) => setForm({ ...form, isbn: e.target.value })}
              />
              <Button type="button" variant="secondary" onClick={lookupISBN} disabled={lookingUp}>
                {lookingUp ? "Looking up…" : "Auto-fill"}
              </Button>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <Field label="Title">
                <input className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </Field>
              <Field label="Author">
                <input className="input" value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} />
              </Field>
              <Field label="Category">
                <input className="input" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
              </Field>
              <Field label="Total Copies">
                <input type="number" min="1" className="input" value={form.total_copies} onChange={(e) => setForm({ ...form, total_copies: e.target.value })} />
              </Field>
              <Field label="Cover Image">
                <input type="file" accept="image/*" onChange={handleCover} />
              </Field>
              <Field label="Digital PDF (optional)">
                <input type="file" accept="application/pdf" onChange={handlePdf} />
              </Field>
            </div>

            <Field label="Description">
              <textarea className="input" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </Field>

            <label className="flex items-center gap-2 text-sm text-gray-600">
              <input type="checkbox" checked={form.is_digital} onChange={(e) => setForm({ ...form, is_digital: e.target.checked })} />
              Available as digital storybook
            </label>

            <Button type="submit">Add book</Button>
          </form>
        </Card>
      )}

      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {books.length === 0 && <p className="text-sm text-gray-400 col-span-full text-center py-10">No books yet.</p>}
        {books.map((b) => (
          <Card key={b.id} className="!p-0 overflow-hidden">
            <div className="h-36 bg-purple-50 flex items-center justify-center">
              {b.cover_url ? (
                <img src={b.cover_url} className="h-full w-full object-cover" />
              ) : (
                <span className="text-4xl">📖</span>
              )}
            </div>
            <div className="p-4">
              <div className="font-semibold text-gray-800 leading-tight">{b.title}</div>
              <div className="text-xs text-gray-400">{b.author}</div>
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <span className="text-xs bg-sky-50 text-sky-600 px-2 py-0.5 rounded-full">
                  {b.available_copies}/{b.total_copies} available
                </span>
                {b.is_digital && <span className="text-xs bg-purple-50 text-purple-600 px-2 py-0.5 rounded-full">Digital</span>}
              </div>
              <button onClick={() => handleDelete(b.id)} className="text-xs text-red-400 mt-3">
                Delete
              </button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="text-sm font-medium text-gray-600">{label}</label>
      <div className="mt-1">{children}</div>
    </div>
  );
}
