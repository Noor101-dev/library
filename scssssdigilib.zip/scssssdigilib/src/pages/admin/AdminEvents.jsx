import React, { useEffect, useState } from "react";
import { MonthlyEvent, UploadFile } from "@/lib/db";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/Toast";

export default function AdminEvents() {
  const toast = useToast();
  const [events, setEvents] = useState([]);
  const [month, setMonth] = useState("");
  const [championName, setChampionName] = useState("");
  const [championPhoto, setChampionPhoto] = useState("");
  const [videoLink, setVideoLink] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setEvents(await MonthlyEvent.list("-month"));
  }

  async function handlePhoto(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await UploadFile({ file });
    setChampionPhoto(file_url);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!month || !championName) {
      toast("Month and champion name are required.", "error");
      return;
    }
    await MonthlyEvent.create({
      month,
      champion_name: championName,
      champion_photo: championPhoto,
      photos: [],
      video_links: videoLink ? [videoLink] : [],
    });
    toast("Event added.", "success");
    setMonth("");
    setChampionName("");
    setChampionPhoto("");
    setVideoLink("");
    load();
  }

  return (
    <div className="space-y-6">
      <h1 className="font-heading text-2xl font-semibold text-gray-800">Monthly Events</h1>

      <Card>
        <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-gray-600">Month</label>
            <input type="month" className="input mt-1" value={month} onChange={(e) => setMonth(e.target.value)} />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600">Champion Name</label>
            <input className="input mt-1" value={championName} onChange={(e) => setChampionName(e.target.value)} />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600">Champion Photo</label>
            <input type="file" accept="image/*" onChange={handlePhoto} className="mt-1" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600">Video Link (optional)</label>
            <input className="input mt-1" value={videoLink} onChange={(e) => setVideoLink(e.target.value)} placeholder="https://…" />
          </div>
          <div className="md:col-span-2">
            <Button type="submit">Add event</Button>
          </div>
        </form>
      </Card>

      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {events.map((e) => (
          <Card key={e.id}>
            <div className="w-16 h-16 rounded-full bg-yellow-50 overflow-hidden mx-auto mb-3">
              {e.champion_photo ? (
                <img src={e.champion_photo} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-2xl">🏆</div>
              )}
            </div>
            <div className="text-center">
              <div className="font-semibold text-gray-800">{e.champion_name}</div>
              <div className="text-xs text-gray-400">{e.month}</div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
