import React, { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Book, Student, Loan } from "@/lib/db";
import { Card } from "@/components/ui/Card";
import { Link } from "react-router-dom";

const PIE_COLORS = ["#8b5cf6", "#f59e0b", "#38bdf8"];

export default function AdminDashboard() {
  const [books, setBooks] = useState([]);
  const [students, setStudents] = useState([]);
  const [loans, setLoans] = useState([]);

  useEffect(() => {
    Book.list().then(setBooks);
    Student.list().then(setStudents);
    Loan.list().then(setLoans);
  }, []);

  const activeLoans = loans.filter((l) => l.status === "active" || l.status === "overdue");
  const blockedStudents = students.filter((s) => s.is_blocked);

  const popularBooks = [...books]
    .sort((a, b) => (b.borrow_count || 0) - (a.borrow_count || 0))
    .slice(0, 5)
    .map((b) => ({ name: b.title.length > 14 ? b.title.slice(0, 14) + "…" : b.title, borrows: b.borrow_count || 0 }));

  const statusPie = [
    { name: "Active", value: students.filter((s) => !s.is_blocked).length },
    { name: "Blocked", value: blockedStudents.length },
  ];

  const classCounts = {};
  students.forEach((s) => {
    const key = s.class || "Unassigned";
    classCounts[key] = (classCounts[key] || 0) + 1;
  });
  const classData = Object.entries(classCounts).map(([name, value]) => ({ name: `Class ${name}`, value }));

  return (
    <div className="space-y-6">
      <h1 className="font-heading text-2xl font-semibold text-gray-800">Dashboard</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Books" value={books.length} icon="📚" />
        <StatCard label="Students" value={students.length} icon="🧑‍🎓" />
        <StatCard label="Active Loans" value={activeLoans.length} icon="📤" />
        <StatCard label="Blocked" value={blockedStudents.length} icon="🚫" />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <h2 className="font-heading font-semibold text-gray-700 mb-3">Most Popular Books</h2>
          {popularBooks.length === 0 ? (
            <EmptyChart />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={popularBooks}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="borrows" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card>
          <h2 className="font-heading font-semibold text-gray-700 mb-3">Student Status</h2>
          {students.length === 0 ? (
            <EmptyChart />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={statusPie} dataKey="value" nameKey="name" outerRadius={80} label>
                  {statusPie.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card className="md:col-span-2">
          <h2 className="font-heading font-semibold text-gray-700 mb-3">Class-wise Distribution</h2>
          {classData.length === 0 ? (
            <EmptyChart />
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={classData}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="value" fill="#38bdf8" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      <div className="flex gap-3">
        <Link to="/admin/issue" className="btn-primary">
          📤 Issue a Book
        </Link>
        <Link to="/admin/books" className="btn-secondary">
          + Add Title
        </Link>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon }) {
  return (
    <Card className="text-center">
      <div className="text-3xl">{icon}</div>
      <div className="font-heading text-2xl font-semibold text-gray-800 mt-1">{value}</div>
      <div className="text-xs text-gray-400">{label}</div>
    </Card>
  );
}

function EmptyChart() {
  return <p className="text-sm text-gray-400 text-center py-10">No data yet.</p>;
}
