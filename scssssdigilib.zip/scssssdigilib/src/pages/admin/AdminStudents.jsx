import React, { useEffect, useRef, useState } from "react";
import { Student, UploadFile } from "@/lib/db";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/Toast";
import { QRSmartPass, downloadPassAsPDF } from "@/components/QRSmartPass";

const emptyForm = {
  full_name: "",
  date_of_birth: "",
  phone: "",
  father_name: "",
  class: "",
  roll_number: "",
  photo_url: "",
};

export default function AdminStudents() {
  const toast = useToast();
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [passStudent, setPassStudent] = useState(null);
  const passRef = useRef(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setStudents(await Student.list("-created_date"));
  }

  const filtered = students.filter((s) => {
    const q = search.toLowerCase();
    return (
      s.full_name.toLowerCase().includes(q) ||
      s.phone.includes(q) ||
      (s.roll_number || "").toLowerCase().includes(q)
    );
  });

  async function handlePhoto(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await UploadFile({ file });
    setForm((f) => ({ ...f, photo_url: file_url }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.full_name || !form.date_of_birth || !form.phone) {
      toast("Name, date of birth and phone are required.", "error");
      return;
    }
    if (editingId) {
      await Student.update(editingId, form);
      toast("Student updated.", "success");
    } else {
      await Student.create({
        ...form,
        points: 0,
        is_blocked: false,
        blocked_reason: "",
        current_streak: 0,
        last_checkin: "",
        owned_avatars: [],
        earned_badges: [],
      });
      toast("Student added.", "success");
    }
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
    load();
  }

  function startEdit(s) {
    setForm({
      full_name: s.full_name,
      date_of_birth: s.date_of_birth,
      phone: s.phone,
      father_name: s.father_name || "",
      class: s.class || "",
      roll_number: s.roll_number || "",
      photo_url: s.photo_url || "",
    });
    setEditingId(s.id);
    setShowForm(true);
  }

  async function toggleBlock(s) {
    if (s.is_blocked) {
      await Student.update(s.id, { is_blocked: false, blocked_reason: "" });
      toast(`${s.full_name} unblocked.`, "success");
    } else {
      const reason = window.prompt("Reason for blocking?", "Overdue book");
      if (reason === null) return;
      await Student.update(s.id, { is_blocked: true, blocked_reason: reason });
      toast(`${s.full_name} blocked.`, "success");
    }
    load();
  }

  async function handleDeletePass() {
    if (!passStudent) return;
    await downloadPassAsPDF(passRef.current, passStudent.full_name);
    setPassStudent(null);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="font-heading text-2xl font-semibold text-gray-800">Students</h1>
        <Button
          onClick={() => {
            setForm(emptyForm);
            setEditingId(null);
            setShowForm((s) => !s);
          }}
        >
          {showForm ? "Cancel" : "+ Add Student"}
        </Button>
      </div>

      {showForm && (
        <Card>
          <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-4">
            <Field label="Full Name">
              <input className="input" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
            </Field>
            <Field label="Date of Birth">
              <input type="date" className="input" value={form.date_of_birth} onChange={(e) => setForm({ ...form, date_of_birth: e.target.value })} />
            </Field>
            <Field label="Phone">
              <input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
            <Field label="Father's Name">
              <input className="input" value={form.father_name} onChange={(e) => setForm({ ...form, father_name: e.target.value })} />
            </Field>
            <Field label="Class">
              <input className="input" value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value })} />
            </Field>
            <Field label="Roll Number">
              <input className="input" value={form.roll_number} onChange={(e) => setForm({ ...form, roll_number: e.target.value })} />
            </Field>
            <Field label="Photo">
              <input type="file" accept="image/*" onChange={handlePhoto} />
            </Field>
            <div className="md:col-span-2">
              <Button type="submit">{editingId ? "Save changes" : "Add student"}</Button>
            </div>
          </form>
        </Card>
      )}

      <Card className="!p-0 overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <input
            className="input"
            placeholder="Search by name, phone, or roll number…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="divide-y divide-gray-100">
          {filtered.length === 0 && <p className="p-6 text-sm text-gray-400 text-center">No students found.</p>}
          {filtered.map((s) => (
            <div key={s.id} className="p-4 flex items-center gap-3 flex-wrap">
              <div className="w-12 h-12 rounded-full bg-purple-100 overflow-hidden flex items-center justify-center shrink-0">
                {s.photo_url ? <img src={s.photo_url} className="w-full h-full object-cover" /> : "🧒"}
              </div>
              <div className="flex-1 min-w-[160px]">
                <div className="font-semibold text-gray-800">{s.full_name}</div>
                <div className="text-xs text-gray-400">
                  Class {s.class || "-"} · Roll {s.roll_number || "-"} · {s.phone}
                </div>
              </div>
              {s.is_blocked && (
                <span className="text-xs font-medium bg-red-50 text-red-500 px-2 py-1 rounded-full">Blocked</span>
              )}
              <div className="flex gap-2">
                <button onClick={() => setPassStudent(s)} className="text-xs font-medium text-brand-purple px-2">
                  Pass
                </button>
                <button onClick={() => startEdit(s)} className="text-xs font-medium text-gray-500 px-2">
                  Edit
                </button>
                <button onClick={() => toggleBlock(s)} className="text-xs font-medium text-gray-500 px-2">
                  {s.is_blocked ? "Unblock" : "Block"}
                </button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {passStudent && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-4 max-w-fit">
            <div style={{ transform: "scale(0.5)", transformOrigin: "top left", width: 1013, height: 638 }}>
              <QRSmartPass student={passStudent} passRef={passRef} />
            </div>
            <div className="flex gap-2 mt-3 justify-end">
              <button onClick={() => setPassStudent(null)} className="btn-secondary text-sm">
                Close
              </button>
              <button onClick={handleDeletePass} className="btn-primary text-sm">
                Download PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="text-sm font-medium text-gray-600">{label}</label>
      <div className="mt-1">{children}</div>
    </div>
  );
}
