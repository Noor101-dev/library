import React, { useState } from "react";
import { Book, Student, Loan } from "@/lib/db";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/Toast";
import { ADMIN_ISSUE_PIN } from "@/lib/AppAuthContext";
import { addDays } from "@/lib/dates";

const STEPS = ["Scan Book", "Confirm PIN", "Find Student", "Confirm Issue"];

export default function AdminIssue() {
  const toast = useToast();
  const [step, setStep] = useState(0);
  const [isbnInput, setIsbnInput] = useState("");
  const [book, setBook] = useState(null);
  const [pin, setPin] = useState("");
  const [phoneInput, setPhoneInput] = useState("");
  const [student, setStudent] = useState(null);
  const [activeLoans, setActiveLoans] = useState([]);
  const [error, setError] = useState("");

  function reset() {
    setStep(0);
    setIsbnInput("");
    setBook(null);
    setPin("");
    setPhoneInput("");
    setStudent(null);
    setActiveLoans([]);
    setError("");
  }

  async function handleFindBook() {
    setError("");
    const matches = await Book.filter({ isbn: isbnInput.trim() });
    const found = matches[0];
    if (!found) {
      setError("No book found with that ISBN.");
      return;
    }
    if (found.available_copies <= 0) {
      setError("No copies available for this title.");
      return;
    }
    setBook(found);
    setStep(1);
  }

  function handlePin() {
    if (pin !== ADMIN_ISSUE_PIN) {
      setError("Incorrect PIN.");
      return;
    }
    setError("");
    setStep(2);
  }

  async function handleFindStudent() {
    setError("");
    const matches = await Student.filter({ phone: phoneInput.trim() });
    const found = matches[0];
    if (!found) {
      setError("No student found with that phone number.");
      return;
    }
    if (found.is_blocked) {
      setError(`${found.full_name} is currently blocked: ${found.blocked_reason || "overdue book"}.`);
      return;
    }
    const loans = await Loan.filter({ student_id: found.id, status: "active" });
    if (loans.length >= 4) {
      setError(`${found.full_name} already has 4 books out — the borrow limit.`);
      return;
    }
    setStudent(found);
    setActiveLoans(loans);
    setStep(3);
  }

  async function handleConfirmIssue() {
    await Loan.create({
      student_id: student.id,
      book_id: book.id,
      book_title: book.title,
      book_cover: book.cover_url,
      issue_date: new Date().toISOString(),
      due_date: addDays(new Date(), 3),
      return_date: null,
      status: "active",
      extensions: 0,
    });
    await Book.update(book.id, {
      available_copies: book.available_copies - 1,
      borrow_count: (book.borrow_count || 0) + 1,
    });
    toast(`Issued "${book.title}" to ${student.full_name}.`, "success");
    reset();
  }

  return (
    <div className="space-y-6 max-w-lg">
      <h1 className="font-heading text-2xl font-semibold text-gray-800">Issue a Book</h1>

      <div className="flex gap-2">
        {STEPS.map((s, i) => (
          <div
            key={s}
            className={
              "flex-1 h-1.5 rounded-full " + (i <= step ? "bg-brand-purple" : "bg-gray-200")
            }
          />
        ))}
      </div>

      <Card>
        {step === 0 && (
          <div className="space-y-3">
            <p className="text-sm text-gray-500">Step 1 — Scan or enter the book's ISBN.</p>
            <input className="input" placeholder="ISBN" value={isbnInput} onChange={(e) => setIsbnInput(e.target.value)} />
            {error && <p className="text-sm text-red-500">{error}</p>}
            <Button onClick={handleFindBook}>Find book</Button>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-3">
            <p className="text-sm text-gray-500">
              Step 2 — Confirm librarian PIN to issue <strong>{book.title}</strong>.
            </p>
            <input className="input" type="password" placeholder="Admin PIN" value={pin} onChange={(e) => setPin(e.target.value)} />
            {error && <p className="text-sm text-red-500">{error}</p>}
            <Button onClick={handlePin}>Confirm PIN</Button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-3">
            <p className="text-sm text-gray-500">Step 3 — Scan or enter the student's phone number.</p>
            <input className="input" placeholder="Phone number" value={phoneInput} onChange={(e) => setPhoneInput(e.target.value)} />
            {error && <p className="text-sm text-red-500">{error}</p>}
            <Button onClick={handleFindStudent}>Find student</Button>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-3">
            <p className="text-sm text-gray-500">Step 4 — Confirm and issue.</p>
            <div className="bg-purple-50 rounded-xl p-4">
              <div className="font-semibold text-gray-800">{book.title}</div>
              <div className="text-xs text-gray-400 mb-2">{book.author}</div>
              <div className="text-sm text-gray-600">
                To: <strong>{student.full_name}</strong> ({activeLoans.length}/4 books currently out)
              </div>
              <div className="text-xs text-gray-400 mt-1">Due in 3 days</div>
            </div>
            <Button onClick={handleConfirmIssue} className="w-full">
              Confirm Issue
            </Button>
            <button onClick={reset} className="text-xs text-gray-400">
              Cancel
            </button>
          </div>
        )}
      </Card>
    </div>
  );
}
