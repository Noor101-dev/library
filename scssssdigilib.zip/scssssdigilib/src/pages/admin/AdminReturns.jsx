import React, { useEffect, useState } from "react";
import { Book, Student, Loan } from "@/lib/db";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { useToast } from "@/components/ui/Toast";
import { getLoanStatus, STATUS_STYLES, addDays } from "@/lib/dates";
import { formatDate } from "@/lib/utils";

export default function AdminReturns() {
  const toast = useToast();
  const [activeLoans, setActiveLoans] = useState([]);
  const [isbnInput, setIsbnInput] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const all = await Loan.list("-created_date");
    setActiveLoans(all.filter((l) => l.status !== "returned"));
  }

  async function returnLoan(loan) {
    await Loan.update(loan.id, { status: "returned", return_date: new Date().toISOString() });
    const book = await Book.get(loan.book_id);
    if (book) {
      await Book.update(book.id, { available_copies: book.available_copies + 1 });
    }
    // Auto-unblock the student if this was their only overdue book
    const student = await Student.get(loan.student_id);
    if (student?.is_blocked) {
      const remainingLoans = await Loan.filter({ student_id: student.id, status: "active" });
      const stillOverdue = remainingLoans.some((l) => new Date(l.due_date) < new Date());
      if (!stillOverdue) {
        await Student.update(student.id, { is_blocked: false, blocked_reason: "" });
      }
    }
    toast(`"${loan.book_title}" returned.`, "success");
    load();
  }

  async function returnByISBN() {
    const matches = await Book.filter({ isbn: isbnInput.trim() });
    const book = matches[0];
    if (!book) {
      toast("No book found with that ISBN.", "error");
      return;
    }
    const loan = activeLoans.find((l) => l.book_id === book.id);
    if (!loan) {
      toast("No active loan found for that book.", "error");
      return;
    }
    await returnLoan(loan);
    setIsbnInput("");
  }

  async function extendLoan(loan) {
    await Loan.update(loan.id, {
      due_date: addDays(loan.due_date, 3),
      extensions: (loan.extensions || 0) + 1,
    });
    toast("Extended by 3 days.", "success");
    load();
  }

  async function sweepOverdue() {
    let count = 0;
    for (const loan of activeLoans) {
      if (getLoanStatus(loan) === "overdue" && loan.status !== "overdue") {
        await Loan.update(loan.id, { status: "overdue" });
        await Student.update(loan.student_id, { is_blocked: true, blocked_reason: "Overdue book" });
        count++;
      }
    }
    toast(count > 0 ? `Marked ${count} loan(s) overdue.` : "No new overdue loans.", "success");
    load();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="font-heading text-2xl font-semibold text-gray-800">Returns</h1>
        <Button variant="secondary" onClick={sweepOverdue}>
          Run overdue sweep
        </Button>
      </div>

      <Card>
        <div className="flex gap-2">
          <input className="input" placeholder="Scan or enter ISBN to return" value={isbnInput} onChange={(e) => setIsbnInput(e.target.value)} />
          <Button onClick={returnByISBN}>Return</Button>
        </div>
      </Card>

      <Card className="!p-0 overflow-hidden">
        <div className="divide-y divide-gray-100">
          {activeLoans.length === 0 && <p className="p-6 text-sm text-gray-400 text-center">No active loans.</p>}
          {activeLoans.map((loan) => {
            const status = getLoanStatus(loan);
            return (
              <div key={loan.id} className="p-4 flex items-center gap-3 flex-wrap">
                <div className="flex-1 min-w-[180px]">
                  <div className="font-semibold text-gray-800">{loan.book_title}</div>
                  <div className="text-xs text-gray-400">Due {formatDate(loan.due_date)}</div>
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-full border ${STATUS_STYLES[status]}`}>
                  {status}
                </span>
                <button onClick={() => extendLoan(loan)} className="text-xs font-medium text-gray-500 px-2">
                  +3 days
                </button>
                <Button onClick={() => returnLoan(loan)} className="!px-3 !py-1.5 !text-sm">
                  Return
                </Button>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
