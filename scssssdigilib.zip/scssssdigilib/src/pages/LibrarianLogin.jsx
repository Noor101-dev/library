import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAppAuth } from "@/lib/AppAuthContext";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";

export default function LibrarianLogin() {
  const { loginLibrarian } = useAppAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await loginLibrarian(email.trim(), password);
      navigate("/admin");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-white to-orange-50 px-4">
      <Card className="w-full max-w-sm animate-pop-in">
        <div className="text-center mb-6">
          <div className="text-5xl mb-2">🗝️</div>
          <h1 className="font-heading text-2xl font-semibold text-brand-deepPurple">Librarian Login</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-600">Email</label>
            <input className="input mt-1" value={email} onChange={(e) => setEmail(e.target.value)} type="email" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600">Password</label>
            <input className="input mt-1" value={password} onChange={(e) => setPassword(e.target.value)} type="password" />
          </div>
          {error && <p className="text-sm text-red-500">{error}</p>}
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Checking…" : "Log in"}
          </Button>
        </form>

        <p className="text-xs text-center mt-5">
          <Link to="/student-login" className="text-brand-purple font-medium">
            ← Student login
          </Link>
        </p>
      </Card>
    </div>
  );
}
