import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAppAuth } from "@/lib/AppAuthContext";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";

export default function StudentLogin() {
  const { loginStudent } = useAppAuth();
  const navigate = useNavigate();
  const [phone, setPhone] = useState("");
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!phone || !day || !month || !year) {
      setError("Please fill in your phone number and full date of birth.");
      return;
    }
    setLoading(true);
    try {
      const dob = `${day.padStart(2, "0")}${month.padStart(2, "0")}${year}`;
      await loginStudent(phone.trim(), dob);
      navigate("/portal");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-white to-sky-50 px-4">
      <Card className="w-full max-w-sm animate-pop-in">
        <div className="text-center mb-6">
          <div className="text-5xl mb-2 animate-float">📚</div>
          <h1 className="font-heading text-2xl font-semibold text-brand-deepPurple">Student Login</h1>
          <p className="text-sm text-gray-400 mt-1">Shaheed Chamkaur Singh Govt Sen Sec School Library</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-600">Phone Number</label>
            <input
              className="input mt-1"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="10-digit phone number"
              inputMode="numeric"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-600">Date of Birth</label>
            <div className="grid grid-cols-3 gap-2 mt-1">
              <input className="input" placeholder="DD" value={day} onChange={(e) => setDay(e.target.value)} maxLength={2} />
              <input className="input" placeholder="MM" value={month} onChange={(e) => setMonth(e.target.value)} maxLength={2} />
              <input className="input" placeholder="YYYY" value={year} onChange={(e) => setYear(e.target.value)} maxLength={4} />
            </div>
          </div>

          {error && <p className="text-sm text-red-500">{error}</p>}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Checking…" : "Log in"}
          </Button>
        </form>

        <p className="text-xs text-gray-400 text-center mt-5">
          Not registered yet? Ask your librarian to add you to the library.
        </p>
        <p className="text-xs text-center mt-3">
          <Link to="/librarian-login" className="text-brand-purple font-medium">
            Librarian login →
          </Link>
        </p>
      </Card>
    </div>
  );
}
