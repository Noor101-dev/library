/**
 * QR Smart Pass — printable library ID card generator
 * ------------------------------------------------------
 * Drop this file into: src/components/QRSmartPass.jsx
 *
 * Usage from AdminStudents.jsx (per student row or bulk):
 *   import { QRSmartPass, downloadPassAsPDF } from "@/components/QRSmartPass";
 *   <QRSmartPass student={student} passRef={passRef} />
 *   <button onClick={() => downloadPassAsPDF(passRef.current, student.full_name)}>
 *     Download Pass
 *   </button>
 *
 * Deps already in your stack: jspdf, html2canvas. QR image is fetched from a
 * public QR-generation endpoint (no new npm dependency needed) — swap the
 * `qrSrc` builder below for a local QR lib later if you want it offline-safe.
 */

import React from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

// Card size tuned for a standard CR80 ID card at ~300dpi (1013x638px)
const CARD_WIDTH = 1013;
const CARD_HEIGHT = 638;

function buildQrPayload(student) {
  // Encode just enough to look the student up fast at issue/return time.
  // AdminIssue / AdminReturns can scan this and match against Student.phone.
  return JSON.stringify({
    type: "student_pass",
    id: student.id,
    phone: student.phone,
  });
}

function qrImageSrc(payload) {
  const encoded = encodeURIComponent(payload);
  // Public, no-key QR image endpoint. Replace with a self-hosted generator
  // if you need this to work fully offline.
  return `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encoded}`;
}

export function QRSmartPass({ student, passRef, schoolName = "Shaheed Chamkaur Singh Govt Sen Sec School" }) {
  const payload = buildQrPayload(student);

  return (
    <div
      ref={passRef}
      style={{
        width: CARD_WIDTH,
        height: CARD_HEIGHT,
        fontFamily: "'Quicksand', sans-serif",
        background: "linear-gradient(135deg, #f4f1ff 0%, #ffffff 60%)",
        border: "6px solid #8b5cf6",
        borderRadius: "36px",
        padding: "36px 44px",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div
            style={{
              fontFamily: "'Fredoka', sans-serif",
              fontSize: 30,
              fontWeight: 600,
              color: "#6d28d9",
              lineHeight: 1.1,
            }}
          >
            Library Smart Pass
          </div>
          <div style={{ fontSize: 16, color: "#6b7280", marginTop: 4 }}>{schoolName}</div>
        </div>
        <div
          style={{
            fontFamily: "'Fredoka', sans-serif",
            fontSize: 14,
            fontWeight: 600,
            color: "#fff",
            background: "#f59e0b",
            borderRadius: 999,
            padding: "6px 16px",
          }}
        >
          Class {student.class || "-"}
        </div>
      </div>

      {/* Body */}
      <div style={{ display: "flex", alignItems: "center", gap: 40, flex: 1 }}>
        <div
          style={{
            width: 150,
            height: 150,
            borderRadius: 24,
            overflow: "hidden",
            border: "4px solid #8b5cf6",
            flexShrink: 0,
            background: "#ede9fe",
          }}
        >
          {student.photo_url ? (
            <img
              src={student.photo_url}
              alt={student.full_name}
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
              crossOrigin="anonymous"
            />
          ) : (
            <div
              style={{
                width: "100%",
                height: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 48,
              }}
            >
              📚
            </div>
          )}
        </div>

        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: "'Fredoka', sans-serif", fontSize: 28, fontWeight: 600, color: "#1f2937" }}>
            {student.full_name}
          </div>
          <div style={{ fontSize: 16, color: "#6b7280", marginTop: 6 }}>
            Roll No: {student.roll_number || "-"}
          </div>
          <div style={{ fontSize: 16, color: "#6b7280", marginTop: 2 }}>
            Phone: {student.phone}
          </div>
          <div style={{ fontSize: 16, color: "#6b7280", marginTop: 2 }}>
            Father: {student.father_name || "-"}
          </div>
        </div>

        <img
          src={qrImageSrc(payload)}
          alt="Scan to identify"
          crossOrigin="anonymous"
          style={{ width: 150, height: 150, borderRadius: 12, background: "#fff", padding: 8 }}
        />
      </div>

      {/* Footer */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          fontSize: 12,
          color: "#9ca3af",
          borderTop: "1px dashed #d1d5db",
          paddingTop: 10,
        }}
      >
        <span>Show this pass at issue/return counter</span>
        <span>Valid for current academic year</span>
      </div>
    </div>
  );
}

/**
 * Renders a mounted QRSmartPass node (via ref) to a PNG and drops it into a
 * single-card PDF sized to match, then triggers a download.
 */
export async function downloadPassAsPDF(node, studentName = "student") {
  if (!node) return;

  const canvas = await html2canvas(node, {
    scale: 2,
    useCORS: true,
    backgroundColor: "#ffffff",
  });

  const imgData = canvas.toDataURL("image/png");

  // mm conversion for a CR80-ish card at the pixel ratio above
  const pdf = new jsPDF({
    orientation: "landscape",
    unit: "mm",
    format: [107, 67], // ~ CR80 card size
  });

  pdf.addImage(imgData, "PNG", 0, 0, 107, 67);
  pdf.save(`smart-pass-${studentName.replace(/\s+/g, "_").toLowerCase()}.pdf`);
}

/**
 * Bulk export: pass an array of {student, node} pairs (e.g. from a hidden
 * off-screen list rendered with QRSmartPass) and get one multi-page PDF.
 */
export async function downloadBulkPassesAsPDF(entries) {
  if (!entries?.length) return;

  const pdf = new jsPDF({ orientation: "landscape", unit: "mm", format: [107, 67] });

  for (let i = 0; i < entries.length; i++) {
    const { node } = entries[i];
    const canvas = await html2canvas(node, { scale: 2, useCORS: true, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    if (i > 0) pdf.addPage([107, 67], "landscape");
    pdf.addImage(imgData, "PNG", 0, 0, 107, 67);
  }

  pdf.save("smart-passes-bulk.pdf");
}
