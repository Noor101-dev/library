import React from "react";
import { Navigate } from "react-router-dom";
import { useAppAuth } from "@/lib/AppAuthContext";

export default function StudentRoute({ children }) {
  const { student } = useAppAuth();
  if (!student) return <Navigate to="/student-login" replace />;
  return children;
}
