import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAppAuth } from "@/lib/AppAuthContext";
import { cn } from "@/lib/utils";

const LINKS = [
  { to: "/admin", label: "Dashboard", icon: "📊", end: true },
  { to: "/admin/students", label: "Students", icon: "🧑‍🎓" },
  { to: "/admin/books", label: "Books", icon: "📚" },
  { to: "/admin/issue", label: "Issue", icon: "📤" },
  { to: "/admin/returns", label: "Returns", icon: "📥" },
  { to: "/admin/events", label: "Events", icon: "🏆" },
];

export default function AdminLayout({ children }) {
  const { logoutLibrarian, librarian } = useAppAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex">
      <aside className="w-60 bg-white border-r border-gray-100 hidden md:flex flex-col shrink-0">
        <div className="p-5 border-b border-gray-100">
          <div className="font-heading text-lg font-semibold text-brand-deepPurple">📖 Librarian</div>
          <div className="text-xs text-gray-400 mt-1 truncate">{librarian?.email}</div>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-4 py-2.5 rounded-xl font-medium text-sm transition-colors",
                  isActive ? "bg-purple-100 text-brand-deepPurple" : "text-gray-600 hover:bg-gray-50"
                )
              }
            >
              <span>{l.icon}</span> {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-gray-100">
          <button
            onClick={() => {
              logoutLibrarian();
              navigate("/librarian-login");
            }}
            className="w-full text-left px-4 py-2.5 rounded-xl text-sm font-medium text-gray-500 hover:bg-gray-50"
          >
            🚪 Log out
          </button>
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="md:hidden bg-white border-b border-gray-100 p-4 flex items-center justify-between">
          <div className="font-heading font-semibold text-brand-deepPurple">📖 Librarian</div>
          <button
            onClick={() => {
              logoutLibrarian();
              navigate("/librarian-login");
            }}
            className="text-sm text-gray-500"
          >
            Log out
          </button>
        </header>
        <div className="md:hidden bg-white border-b border-gray-100 px-2 pb-2 flex gap-1 overflow-x-auto">
          {LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                cn(
                  "px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap",
                  isActive ? "bg-purple-100 text-brand-deepPurple" : "text-gray-500"
                )
              }
            >
              {l.icon} {l.label}
            </NavLink>
          ))}
        </div>
        <main className="p-4 md:p-8 max-w-6xl mx-auto">{children}</main>
      </div>
    </div>
  );
}
