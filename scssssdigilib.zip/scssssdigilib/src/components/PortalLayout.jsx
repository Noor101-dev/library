import React, { useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAppAuth } from "@/lib/AppAuthContext";
import { Student } from "@/lib/db";
import BlockedScreen from "./BlockedScreen";
import { cn } from "@/lib/utils";

const LINKS = [
  { to: "/portal", label: "Home", icon: "🏠", end: true },
  { to: "/portal/badges", label: "Badges", icon: "🏅" },
  { to: "/portal/leaderboard", label: "Ranks", icon: "🏆" },
  { to: "/portal/wishlist", label: "Wishlist", icon: "💭" },
  { to: "/portal/shop", label: "Shop", icon: "🛍️" },
];

export default function PortalLayout({ children }) {
  const { student, logoutStudent } = useAppAuth();
  const navigate = useNavigate();
  const [fresh, setFresh] = useState(null);

  useEffect(() => {
    let cancelled = false;
    Student.get(student.id).then((s) => {
      if (!cancelled) setFresh(s);
    });
    return () => {
      cancelled = true;
    };
  }, [student.id]);

  if (fresh?.is_blocked) {
    return (
      <PortalShell student={student} onLogout={() => { logoutStudent(); navigate("/student-login"); }}>
        <BlockedScreen reason={fresh.blocked_reason} />
      </PortalShell>
    );
  }

  return (
    <PortalShell student={student} points={fresh?.points} onLogout={() => { logoutStudent(); navigate("/student-login"); }}>
      {children}
    </PortalShell>
  );
}

function PortalShell({ student, points, onLogout, children }) {
  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="font-heading font-semibold text-brand-deepPurple">📚 {student.full_name}</div>
          <div className="flex items-center gap-3">
            {typeof points === "number" && (
              <span className="text-xs font-semibold bg-brand-yellow/30 text-amber-700 px-3 py-1 rounded-full">
                ⭐ {points} pts
              </span>
            )}
            <button onClick={onLogout} className="text-sm text-gray-400 hover:text-gray-600">
              Log out
            </button>
          </div>
        </div>
        <nav className="max-w-4xl mx-auto px-2 hidden md:flex gap-1 pb-2">
          {LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                cn(
                  "px-4 py-1.5 rounded-full text-sm font-medium",
                  isActive ? "bg-purple-100 text-brand-deepPurple" : "text-gray-500 hover:bg-gray-50"
                )
              }
            >
              {l.icon} {l.label}
            </NavLink>
          ))}
        </nav>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">{children}</main>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 flex justify-around py-2 z-40">
        {LINKS.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            end={l.end}
            className={({ isActive }) =>
              cn("flex flex-col items-center text-xs px-2", isActive ? "text-brand-deepPurple" : "text-gray-400")
            }
          >
            <span className="text-lg">{l.icon}</span>
            {l.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
