import React from "react";
import { cn } from "@/lib/utils";

export function Button({ variant = "primary", className, children, ...props }) {
  const base = variant === "primary" ? "btn-primary" : variant === "secondary" ? "btn-secondary" : "";
  return (
    <button className={cn(base, className)} {...props}>
      {children}
    </button>
  );
}
