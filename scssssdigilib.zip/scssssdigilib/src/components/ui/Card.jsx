import React from "react";
import { cn } from "@/lib/utils";

export function Card({ className, children, ...props }) {
  return (
    <div className={cn("card p-5", className)} {...props}>
      {children}
    </div>
  );
}
