import React, { useState } from "react";

export default function ImageReader({ book, onReachedLastPage }) {
  const pages = book.digital_pages || [];
  const [pageIndex, setPageIndex] = useState(0);

  function next() {
    if (pageIndex >= pages.length - 1) {
      onReachedLastPage?.();
      return;
    }
    setPageIndex((p) => p + 1);
  }

  function prev() {
    setPageIndex((p) => Math.max(0, p - 1));
  }

  if (pages.length === 0) {
    return <p className="text-center text-gray-400 py-16">No scanned pages for this book yet.</p>;
  }

  return (
    <div className="flex flex-col items-center py-6 px-4">
      <div className="bg-white shadow-md rounded-xl overflow-hidden max-w-full">
        <img src={pages[pageIndex]} alt={`Page ${pageIndex + 1}`} className="max-w-full h-auto max-h-[70vh]" />
      </div>
      <div className="flex items-center gap-4 mt-4">
        <button onClick={prev} disabled={pageIndex === 0} className="btn-secondary !px-4 !py-2 disabled:opacity-40">
          ← Prev
        </button>
        <span className="text-sm text-gray-500">
          {pageIndex + 1} / {pages.length}
        </span>
        <button onClick={next} className="btn-primary !px-4 !py-2">
          {pageIndex >= pages.length - 1 ? "Finish" : "Next →"}
        </button>
      </div>
    </div>
  );
}
