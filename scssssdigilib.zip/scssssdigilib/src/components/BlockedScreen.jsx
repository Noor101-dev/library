import React from "react";

export default function BlockedScreen({ reason }) {
  return (
    <div className="min-h-[60vh] flex items-center justify-center text-center px-6">
      <div>
        <div className="text-6xl mb-4">🔒</div>
        <h2 className="font-heading text-2xl font-semibold text-gray-800 mb-2">Account paused</h2>
        <p className="text-gray-500 max-w-sm">
          {reason || "Please return your overdue book to the librarian to continue reading."}
        </p>
      </div>
    </div>
  );
}
