import React, { useEffect, useRef, useState } from "react";
import * as pdfjsLib from "pdfjs-dist";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

export default function PdfReader({ book, onReachedLastPage }) {
  const canvasRef = useRef(null);
  const [pdf, setPdf] = useState(null);
  const [pageNum, setPageNum] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!book.digital_pdf_url) {
      setError("No PDF uploaded for this book yet.");
      setLoading(false);
      return;
    }
    let cancelled = false;
    pdfjsLib
      .getDocument(book.digital_pdf_url)
      .promise.then((doc) => {
        if (cancelled) return;
        setPdf(doc);
        setNumPages(doc.numPages);
        setLoading(false);
      })
      .catch(() => {
        if (!cancelled) {
          setError("Couldn't load this PDF.");
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [book.digital_pdf_url]);

  useEffect(() => {
    if (!pdf) return;
    renderPage(pageNum);
  }, [pdf, pageNum]);

  async function renderPage(num) {
    const page = await pdf.getPage(num);
    const viewport = page.getViewport({ scale: 1.4 });
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext("2d");
    await page.render({ canvasContext: ctx, viewport }).promise;
  }

  function readAloud() {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(`Page ${pageNum} of ${book.title}`);
    window.speechSynthesis.speak(utter);
  }

  function next() {
    if (pageNum >= numPages) {
      onReachedLastPage?.();
      return;
    }
    setPageNum((p) => p + 1);
  }

  function prev() {
    setPageNum((p) => Math.max(1, p - 1));
  }

  if (loading) return <p className="text-center text-gray-400 py-16">Loading book…</p>;
  if (error) return <p className="text-center text-gray-400 py-16">{error}</p>;

  return (
    <div className="flex flex-col items-center py-6 px-4">
      <div className="bg-white shadow-md rounded-xl overflow-hidden max-w-full">
        <canvas ref={canvasRef} className="max-w-full h-auto" />
      </div>
      <div className="flex items-center gap-4 mt-4">
        <button onClick={prev} disabled={pageNum <= 1} className="btn-secondary !px-4 !py-2 disabled:opacity-40">
          ← Prev
        </button>
        <span className="text-sm text-gray-500">
          {pageNum} / {numPages}
        </span>
        <button onClick={next} className="btn-primary !px-4 !py-2">
          {pageNum >= numPages ? "Finish" : "Next →"}
        </button>
      </div>
      <button onClick={readAloud} className="text-xs text-brand-purple font-medium mt-3">
        🔊 Read this page aloud
      </button>
    </div>
  );
}
