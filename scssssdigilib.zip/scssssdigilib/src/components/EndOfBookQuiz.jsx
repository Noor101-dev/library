/**
 * End-of-book mini-quiz — wires the existing `Quiz` entity into the reader.
 * ---------------------------------------------------------------------------
 * Drop this file into: src/components/EndOfBookQuiz.jsx
 *
 * Data model (already in your entities list):
 *   Quiz { book_id, questions: [{ question, options: [], answer }] }
 *
 * Wire-up in PdfReader.jsx / ImageReader.jsx:
 *
 *   import { EndOfBookQuiz } from "@/components/EndOfBookQuiz";
 *   import { Quiz } from "@/api/entities"; // adjust to your Base44 SDK import path
 *
 *   const [showQuiz, setShowQuiz] = useState(false);
 *
 *   // when the reader detects the last page was reached:
 *   function handleReachedLastPage() {
 *     setShowQuiz(true);
 *   }
 *
 *   {showQuiz && (
 *     <EndOfBookQuiz
 *       bookId={book.id}
 *       studentId={currentStudent.id}
 *       onClose={() => setShowQuiz(false)}
 *       onAwardPoints={(pts) => updateStudentPoints(pts)}
 *     />
 *   )}
 *
 * Points rule matches your existing scheme (+2 per review) — quiz awards
 * +1 point per correct answer, capped at +5 for a perfect run. Adjust
 * POINTS_PER_CORRECT / MAX_POINTS below if you want different numbers.
 */

import React, { useEffect, useState } from "react";

const POINTS_PER_CORRECT = 1;
const MAX_POINTS = 5;

export function EndOfBookQuiz({ bookId, studentId, fetchQuizForBook, submitQuizResult, onClose, onAwardPoints }) {
  const [quiz, setQuiz] = useState(null);
  const [loading, setLoading] = useState(true);
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        // fetchQuizForBook should call your Base44 SDK, e.g.:
        //   const results = await Quiz.filter({ book_id: bookId });
        //   return results[0] || null;
        const found = await fetchQuizForBook(bookId);
        if (!cancelled) setQuiz(found);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [bookId, fetchQuizForBook]);

  if (loading) {
    return (
      <QuizShell onClose={onClose}>
        <p className="text-center text-gray-500 py-10">Loading quiz…</p>
      </QuizShell>
    );
  }

  // No quiz configured for this book yet — skip gracefully, no dead end for the student.
  if (!quiz || !quiz.questions?.length) {
    return (
      <QuizShell onClose={onClose}>
        <div className="text-center py-10">
          <div className="text-4xl mb-2">📖</div>
          <p className="text-gray-600 font-medium">Nice reading! No quiz for this book yet.</p>
          <button
            onClick={onClose}
            className="mt-6 px-6 py-2 rounded-full bg-purple-500 text-white font-semibold"
          >
            Close
          </button>
        </div>
      </QuizShell>
    );
  }

  const questions = quiz.questions;
  const q = questions[current];

  function handleSelect(option) {
    if (selected !== null) return; // lock after first pick
    setSelected(option);
    const isCorrect = option === q.answer;
    if (isCorrect) setCorrectCount((c) => c + 1);

    setTimeout(() => {
      if (current + 1 < questions.length) {
        setCurrent((c) => c + 1);
        setSelected(null);
      } else {
        finish(isCorrect ? correctCount + 1 : correctCount);
      }
    }, 700);
  }

  async function finish(finalCorrect) {
    const earned = Math.min(finalCorrect * POINTS_PER_CORRECT, MAX_POINTS);
    setFinished(true);
    try {
      // submitQuizResult should persist the attempt if you want history, e.g.:
      //   await QuizAttempt.create({ student_id: studentId, book_id: bookId, score: finalCorrect, total: questions.length });
      if (submitQuizResult) {
        await submitQuizResult({ studentId, bookId, score: finalCorrect, total: questions.length, pointsEarned: earned });
      }
    } finally {
      onAwardPoints?.(earned);
    }
  }

  if (finished) {
    const earned = Math.min(correctCount * POINTS_PER_CORRECT, MAX_POINTS);
    return (
      <QuizShell onClose={onClose}>
        <div className="text-center py-8">
          <div className="text-5xl mb-3">{correctCount === questions.length ? "🏆" : "🎉"}</div>
          <p className="text-xl font-bold text-gray-800">
            {correctCount} / {questions.length} correct
          </p>
          <p className="text-purple-600 font-semibold mt-1">+{earned} points earned</p>
          <button
            onClick={onClose}
            className="mt-6 px-6 py-2 rounded-full bg-purple-500 text-white font-semibold"
          >
            Done
          </button>
        </div>
      </QuizShell>
    );
  }

  return (
    <QuizShell onClose={onClose}>
      <div className="px-2">
        <div className="text-xs text-gray-400 font-medium mb-2">
          Question {current + 1} of {questions.length}
        </div>
        <p className="text-lg font-semibold text-gray-800 mb-4">{q.question}</p>
        <div className="space-y-2">
          {q.options.map((opt) => {
            const isSelected = selected === opt;
            const isAnswer = opt === q.answer;
            const showState = selected !== null;
            return (
              <button
                key={opt}
                onClick={() => handleSelect(opt)}
                disabled={selected !== null}
                className={[
                  "w-full text-left px-4 py-3 rounded-xl border-2 font-medium transition-colors",
                  !showState && "border-gray-200 hover:border-purple-300",
                  showState && isAnswer && "border-green-400 bg-green-50",
                  showState && isSelected && !isAnswer && "border-red-300 bg-red-50",
                  showState && !isSelected && !isAnswer && "border-gray-200 opacity-60",
                ]
                  .filter(Boolean)
                  .join(" ")}
              >
                {opt}
              </button>
            );
          })}
        </div>
      </div>
    </QuizShell>
  );
}

function QuizShell({ children, onClose }) {
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-xl relative">
        <button
          onClick={onClose}
          className="absolute top-3 right-4 text-gray-400 hover:text-gray-600 text-xl"
          aria-label="Close quiz"
        >
          ×
        </button>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
