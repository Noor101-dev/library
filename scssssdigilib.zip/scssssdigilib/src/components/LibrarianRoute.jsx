import React from "react";
import { Navigate } from "react-router-dom";
import { useAppAuth } from "@/lib/AppAuthContext";

export default function LibrarianRoute({ children }) {
  const { librarian } = useAppAuth();
  if (!librarian) return <Navigate to="/librarian-login" replace />;
  return children;
}
